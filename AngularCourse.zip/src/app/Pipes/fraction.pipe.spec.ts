import { FractionPipe } from './fraction.pipe';

describe('FractionPipe', () => {
  it('create an instance', () => {
    const pipe = new FractionPipe();
    expect(pipe).toBeTruthy();
  });
});
