export interface IRating {
  rate:number,
  count:number
}
