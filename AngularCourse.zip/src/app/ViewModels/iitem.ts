export interface IItem {
  image:string,
  name:string,
  price:number,
  quantity:number,
}
